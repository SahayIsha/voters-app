
import 'package:flutter/material.dart';
import 'dart:async';

void main() => runApp(VotersApp());

class VotersApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Voters App',
      theme: ThemeData(
        primaryColor: Color(0xFF1D4ED8),
        scaffoldBackgroundColor: Color(0xFFF9FAFB),
        textTheme: ThemeData.light().textTheme.copyWith(
              bodyLarge: TextStyle(color: Color(0xFF111827)),
              bodyMedium: TextStyle(color: Color(0xFF111827)),
            ),
        fontFamily: 'Inter',
        useMaterial3: true,
      ),
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController urlController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Enter Password", style: Theme.of(context).textTheme.headlineSmall),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(labelText: 'Password'),
            ),
            SizedBox(height: 20),
            Text("Enter Sync URL", style: Theme.of(context).textTheme.headlineSmall),
            TextField(
              controller: urlController,
              decoration: InputDecoration(labelText: 'Sync URL'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => WaitingPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF2563EB),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: Text("Sync System"),
            )
          ],
        ),
      ),
    );
  }
}

class WaitingPage extends StatefulWidget {
  @override
  _WaitingPageState createState() => _WaitingPageState();
}

class _WaitingPageState extends State<WaitingPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => VotingPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Color(0xFF1D4ED8)),
            SizedBox(height: 20),
            Text("Waiting for Operator...", style: Theme.of(context).textTheme.headlineSmall)
          ],
        ),
      ),
    );
  }
}

class VotingPage extends StatefulWidget {
  @override
  _VotingPageState createState() => _VotingPageState();
}

class _VotingPageState extends State<VotingPage> {
  final List<Map<String, String>> parties = [
    {'number': '1', 'name': 'Party Alpha', 'code': 'PA'},
    {'number': '2', 'name': 'Party Beta', 'code': 'PB'},
    {'number': '3', 'name': 'Party Gamma', 'code': 'PG'},
  ];

  String? selectedPartyCode;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Voting')),
      body: ListView.builder(
        itemCount: parties.length,
        itemBuilder: (context, index) {
          final party = parties[index];
          final isSelected = selectedPartyCode == party['code'];

          return Card(
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            color: isSelected ? Color(0xFFD1FAE5) : null,
            child: ListTile(
              title: Text(party['name']!),
              subtitle: Text('Code: ${party['code']}'),
              trailing: ElevatedButton(
                onPressed: () {
                  setState(() {
                    selectedPartyCode = party['code'];
                  });
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ConfirmationPage(party: party)),
                  );
                },
                child: Text('Vote'),
              ),
            ),
          );
        },
      ),
    );
  }
}

class ConfirmationPage extends StatelessWidget {
  final Map<String, String> party;

  ConfirmationPage({required this.party});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Confirm Vote')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.check_circle_outline, size: 80, color: Color(0xFF10B981)),
            SizedBox(height: 20),
            Text('Confirm your vote for:', style: Theme.of(context).textTheme.headlineSmall),
            SizedBox(height: 20),
            Text('${party['name']} (${party['code']})', style: TextStyle(fontSize: 20)),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => ThankYouPage()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF10B981),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: Text('Confirm Vote'),
            )
          ],
        ),
      ),
    );
  }
}

class ThankYouPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: AnimatedOpacity(
          opacity: 1.0,
          duration: Duration(seconds: 2),
          child: Text(
            'Thank You for Voting!',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF10B981)),
          ),
        ),
      ),
    );
  }
}
